look = 'It\'s a nice basket, full of goodies'
# if talk to mom: look = look + 'for your granny'