id = 1
name = 'house'
content = {
    'mom',
    'basket',
    'door'
}
look_around = """You are in your house. It\'s familiar and comfortable as ever.
Your mother looks at you, she seems to have a task to assign you.
A basket is standing in front of you, full of food and nice things.
At your back, a door that brings you outside."""