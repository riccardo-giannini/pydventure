class Onscene():
    look = ''
    use = ''
    take = ''
    talk = ''
    go = ''